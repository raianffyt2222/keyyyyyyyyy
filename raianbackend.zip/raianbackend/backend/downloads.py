"""Handling of game additions via Sushi API following the 10-step flow."""

import json
import os
import shutil
import zipfile
import threading
from typing import Any, Dict

import Millennium  # type: ignore
from http_client import ensure_http_client
from logger import logger
from paths import backend_path

# State management for frontend progress tracking
INSTALL_STATE: Dict[int, Dict[str, Any]] = {}
INSTALL_LOCK = threading.Lock()

def _set_install_state(appid: int, update: dict) -> None:
    with INSTALL_LOCK:
        state = INSTALL_STATE.get(appid) or {}
        state.update(update)
        INSTALL_STATE[appid] = state

def _get_install_state(appid: int) -> dict:
    with INSTALL_LOCK:
        return INSTALL_STATE.get(appid, {}).copy()

def get_installation_status(appid: int) -> str:
    try:
        appid = int(appid)
    except:
        return json.dumps({"success": False, "error": "Invalid appid"})
    state = _get_install_state(appid)
    return json.dumps({"success": True, "state": state})

def _process_activation_flow(appid: int):
    logger.log(f"ActivationFlow: started for appid={appid}")
    try:
        # 2. Download via Sushi URL
        url = f"https://github.com/raianffyt2222/reporaianlmm/raw/main/{appid}.zip"
        
        # 3. Criar pasta temporária
        temp_dir = backend_path("temp_cubyc")
        os.makedirs(temp_dir, exist_ok=True)
        zip_path = os.path.join(temp_dir, f"{appid}.zip")

        _set_install_state(appid, {"status": "downloading", "msg": "Baixando arquivos do Sushi..."})
        logger.log(f"ActivationFlow: downloading {url}")

        # 4. Download do arquivo (using our urllib client)
        client = ensure_http_client("SushiDownload")
        response = client.get(url, timeout=15)

        # Sushi sometimes returns 400 with a valid ZIP payload
        if response.status_code not in [200, 400]:
            raise Exception(f"Falha ao baixar arquivo: Status {response.status_code}")

        with open(zip_path, "wb") as f:
            f.write(response.content)

        # 5. Validação do ZIP (ESSENCIAL)
        with open(zip_path, "rb") as f:
            magic = f.read(4)

        if magic not in [b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"]:
            raise Exception("Arquivo inválido (não é zip)")

        _set_install_state(appid, {"status": "installing", "msg": "Instalando arquivos..."})
        logger.log("ActivationFlow: zip valid, extracting...")

        # 6. Extração
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        # 7. Caminhos do Steam
        steam_path = Millennium.steam_path()
        plugin_path = os.path.join(steam_path, "config", "stplug-in")
        depot_path = os.path.join(steam_path, "depotcache")

        os.makedirs(plugin_path, exist_ok=True)
        os.makedirs(depot_path, exist_ok=True)

        # 8. Instalação dos arquivos
        lua_encontrado = False
        for root, _, files in os.walk(temp_dir):
            for file in files:
                full_path = os.path.join(root, file)
                if file.lower().endswith(".lua"):
                    # DO NOT RENAME: Move directly as specified by user
                    target_lua = os.path.join(plugin_path, file)
                    shutil.copy(full_path, target_lua)
                    logger.log(f"ActivationFlow: installed LUA -> {target_lua}")
                    lua_encontrado = True
                elif file.lower().endswith(".manifest"):
                    target_manifest = os.path.join(depot_path, file)
                    shutil.copy(full_path, target_manifest)
                    logger.log(f"ActivationFlow: installed Manifest -> {target_manifest}")

        # 9. Validação final
        if not lua_encontrado:
            raise Exception("Nenhum arquivo .lua encontrado no pacote")

        # 10. Limpeza
        shutil.rmtree(temp_dir, ignore_errors=True)
        
        _set_install_state(appid, {"status": "done", "msg": "Concluído com sucesso!"})
        logger.log(f"ActivationFlow: success for appid={appid}")

    except Exception as e:
        logger.error(f"ActivationFlow: failed: {e}")
        _set_install_state(appid, {"status": "failed", "error": str(e)})
        # Cleanup on failure
        try: shutil.rmtree(backend_path("temp_cubyc"), ignore_errors=True)
        except: pass

def start_installation(appid: int) -> str:
    logger.log(f"start_installation: invoked for appid {appid}")
    try:
        appid = int(appid)
    except:
        return json.dumps({"success": False, "error": "Invalid appid"})

    _set_install_state(appid, {"status": "queued", "msg": "Iniciando..."})
    threading.Thread(target=_process_activation_flow, args=(appid,), daemon=True).start()
    return json.dumps({"success": True})

__all__ = ["start_installation", "get_installation_status"]
