import json
import os
import shutil
import sys
import webbrowser
import datetime
import traceback
import threading

import Millennium  # type: ignore

from config import WEBKIT_DIR_NAME, WEB_UI_JS_FILE, WEB_UI_ICON_FILE
from api_manifest import init_apis as api_init_apis
from downloads import start_installation, get_installation_status
from paths import get_plugin_dir, public_path
from http_client import ensure_http_client

def ak_log(msg: str):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[AK-LOG] {msg}")
    try:
        log_path = os.path.join(get_plugin_dir(), "debug_ak.txt")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {msg}\n")
    except: pass

# --- BRIDGE METHODS (GLOBAL FUNCTIONS) ---

def StartInstallation(appid: int, contentScriptQuery: str = "") -> str:
    """Legacy AppID installation."""
    ak_log(f"StartInstallation: appid={appid}")
    try:
        res = start_installation(int(appid))
        return res
    except Exception as e:
        err = traceback.format_exc()
        ak_log(f"StartInstallation Error: {err}")
        return json.dumps({"success": False, "error": str(e)})

def ActivateProductKey(key: str, contentScriptQuery: str = "") -> str:
    """Main entry point for key-based activation via localhost:3001."""
    ak_log(f"ActivateProductKey: key={key}")
    try:
        client = ensure_http_client("KeyActivation")
        base_url = "https://backendlmt.squareweb.app/api"
        
        # 1. Check Key Status
        ak_log(f"ActivateProductKey: Checking key status at {base_url}/check-key")
        check_resp = client.post(f"{base_url}/check-key", json={"key": key})
        
        ak_log(f"Check-Key Response: {check_resp.status_code} - {check_resp.text}")
        
        if check_resp.status_code != 200:
            return json.dumps({"success": False, "error": f"Erro do servidor ({check_resp.status_code})"})
        
        check_data = check_resp.json()
        if not check_data.get("success"):
            return json.dumps({"success": False, "error": check_data.get("message", "Key inválida ou inativa")})
        
        # 2. Finalize/Activate Key (Mark as used)
        ak_log(f"ActivateProductKey: Finalizing key at {base_url}/finalize-key")
        final_resp = client.post(f"{base_url}/finalize-key", json={"key": key})
        
        ak_log(f"Finalize-Key Response: {final_resp.status_code} - {final_resp.text}")
        
        if final_resp.status_code != 200:
            # We skip error if finalize fails but check-key was okay? No, finalize is critical.
            final_data = final_resp.json()
            if not final_data.get("success"):
                 return json.dumps({"success": False, "error": final_data.get("message", "Falha ao consumir key")})

        # 3. Trigger Downloads for all AppIDs
        appids = check_data.get("appids", [])
        if not appids:
            return json.dumps({"success": False, "error": "Nenhum AppID vinculado a esta key"})
        
        ak_log(f"ActivateProductKey: Triggering downloads for {appids}")
        for aid in appids:
            try:
                start_installation(int(aid))
            except Exception as ex:
                ak_log(f"Failed to start installation for {aid}: {ex}")

        # 4. Success - Return data
        games = check_data.get("games", [])
        return json.dumps({"success": True, "appids": appids, "games": games, "message": "Key ativada com sucesso!"})

    except Exception as e:
        err = traceback.format_exc()
        ak_log(f"ActivateProductKey ERROR: {err}")
        return json.dumps({"success": False, "error": str(e)})

def GetAddStatus(appid: int, contentScriptQuery: str = "") -> str:
    try:
        return get_installation_status(int(appid))
    except:
        return json.dumps({"success": False})

class Logger:
    @staticmethod
    def log(message: str) -> str:
        ak_log(f"[JS] {message}")
        return json.dumps({"success": True})

# --- LIFECYCLE CLASS ---

class Plugin:
    def _copy_webkit_files(self) -> None:
        try:
            steam_ui_path = os.path.join(Millennium.steam_path(), "steamui", WEBKIT_DIR_NAME)
            os.makedirs(steam_ui_path, exist_ok=True)
            js_src = public_path(WEB_UI_JS_FILE)
            js_dst = os.path.join(steam_ui_path, WEB_UI_JS_FILE)
            shutil.copy(js_src, js_dst)
            # ak_log(f"Injected JS to {js_dst}")
        except: pass

    def _inject_webkit_files(self) -> None:
        try:
            js_path = os.path.join(WEBKIT_DIR_NAME, WEB_UI_JS_FILE)
            Millennium.add_browser_js(js_path)
            # ak_log(f"Browser JS Added: {js_path}")
        except: pass

    def _load(self):
        ak_log(f"Plugin _load sequence (Millennium {Millennium.version()})")
        try:
            api_init_apis("boot")
        except: pass
        self._copy_webkit_files()
        self._inject_webkit_files()
        Millennium.ready()

    def _unload(self):
        ak_log("Plugin unloading")

plugin = Plugin()
